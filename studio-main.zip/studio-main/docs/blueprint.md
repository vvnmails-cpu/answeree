# **App Name**: Answeree Hub

## Core Features:

- Daily Data Fetch: Fetch top Q&A from Reddit and Hacker News daily.
- AI Summarization: Summarize long answers using the OpenAI or Gemini API. The LLM will use the tool to decide whether the summarization is necessary.
- Firestore Storage: Store the fetched and summarized Q&A in Firestore.
- Public Website Display: Display today’s answers in card format on a public website.
- Category Filter: Implement a category filter (Tech, Science, Lifestyle, General).
- Previous Days Digests: Load older digests from Firestore with pagination.
- Admin Panel: Admin panel protected by Firebase Auth for content management.

## Style Guidelines:

- Primary color: Light blue (#ADD8E6) to evoke calmness and knowledge.
- Background color: Very light blue (#F0F8FF), almost white, to ensure readability and a clean aesthetic.
- Accent color: A slightly more saturated sky blue (#87CEEB) for interactive elements and highlights.
- Headline font: 'Belleza' sans-serif for a stylish but tech-relevant impression; body font: 'Alegreya' serif to aid readability for the summaries.
- Use simple, clear icons for source (Reddit/HN) and categories.
- Minimal card-based layout with a white background.
- Subtle animations for loading new data and category filtering.