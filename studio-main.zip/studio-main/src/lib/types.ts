export type DailyAnswer = {
  id: string;
  title: string;
  answer: string;
  fullAnswer: string;
  source: 'Reddit' | 'Hacker News';
  url: string;
  upvotes: number;
  category: 'Tech' | 'Science' | 'Lifestyle' | 'General';
  date: string; // YYYY-MM-DD
  status: 'pending' | 'approved' | 'rejected';
};
