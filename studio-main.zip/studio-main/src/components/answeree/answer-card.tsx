import type { DailyAnswer } from '@/lib/types';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowBigUp, ExternalLink } from 'lucide-react';
import { HackerNewsIcon, RedditIcon } from '../icons';
import { Badge } from '@/components/ui/badge';

interface AnswerCardProps {
  answer: DailyAnswer;
}

const SourceIcon = ({ source }: { source: DailyAnswer['source'] }) => {
  if (source === 'Reddit') {
    return <RedditIcon className="h-6 w-6 text-orange-500" />;
  }
  if (source === 'Hacker News') {
    return <HackerNewsIcon className="h-5 w-5 text-orange-600" />;
  }
  return null;
};

export default function AnswerCard({ answer }: AnswerCardProps) {
  return (
    <Card className="flex flex-col overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 duration-300 ease-in-out">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center gap-2">
          <SourceIcon source={answer.source} />
          <span className="text-sm font-medium text-muted-foreground">{answer.source}</span>
        </div>
        <Badge variant="outline">{answer.category}</Badge>
      </CardHeader>
      <CardContent className="flex-grow">
        <CardTitle className="font-headline text-xl mb-2 leading-tight">{answer.title}</CardTitle>
        <CardDescription className="font-body text-base leading-relaxed">{answer.answer}</CardDescription>
      </CardContent>
      <CardFooter className="flex justify-between items-center bg-muted/50 pt-4">
        <div className="flex items-center gap-1 text-muted-foreground">
          <ArrowBigUp className="h-5 w-5" />
          <span className="font-semibold text-sm">{answer.upvotes.toLocaleString()}</span>
        </div>
        <Button asChild size="sm" variant="secondary">
          <a href={answer.url} target="_blank" rel="noopener noreferrer">
            View Source <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
}
