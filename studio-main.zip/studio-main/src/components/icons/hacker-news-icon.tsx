export const HackerNewsIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg fill="currentColor" viewBox="0 0 24 24" {...props}>
        <path d="M4 4h16v16H4V4m1.5 1.5v13h13v-13h-13M10.9 8.2H9.1v7.6h1.8V8.2m4.2 0h-1.8v3.3l-2.4-3.3H9.1v7.6h1.8V9.5l2.7 3.8h1.6V8.2Z" />
    </svg>
);
