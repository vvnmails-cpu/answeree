'use client';

import { useState, useMemo } from 'react';
import { mockData } from '@/lib/data';
import AnswerCard from '@/components/answeree/answer-card';
import CategoryFilters from '@/components/answeree/category-filters';
import { Button } from '@/components/ui/button';
import { format, subDays, isAfter, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const ALL_CATEGORIES = 'All';
const CATEGORIES = [ALL_CATEGORIES, 'Tech', 'Science', 'Lifestyle', 'General'];

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<string>(ALL_CATEGORIES);
  const [daysAgo, setDaysAgo] = useState(0);

  const currentDate = useMemo(() => subDays(new Date(), daysAgo), [daysAgo]);
  const currentDateString = useMemo(() => format(currentDate, 'yyyy-MM-dd'), [currentDate]);

  const filteredAnswers = useMemo(() => {
    return mockData.filter((item) => {
      const isCurrentDate = item.date === currentDateString;
      const isApproved = item.status === 'approved';
      const categoryMatch = activeCategory === ALL_CATEGORIES || item.category === activeCategory;
      return isCurrentDate && isApproved && categoryMatch;
    });
  }, [currentDateString, activeCategory]);

  const earliestDate = useMemo(() => {
    return mockData.reduce((earliest, item) => {
       const itemDate = parseISO(item.date);
       return isAfter(earliest, itemDate) ? itemDate : earliest;
    }, new Date());
  }, []);
  
  const canGoBack = isAfter(currentDate, earliestDate);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-headline font-bold tracking-tight lg:text-5xl">
          Daily Knowledge Digest
        </h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Top answers from across the web, summarized for you.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <CategoryFilters
          categories={CATEGORIES}
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
        />
         <div className="flex items-center gap-2">
          <Button onClick={() => setDaysAgo(daysAgo + 1)} disabled={!canGoBack} variant="outline" size="icon">
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Previous Day</span>
          </Button>
          <Button onClick={() => setDaysAgo(daysAgo - 1)} disabled={daysAgo === 0} variant="outline" size="icon">
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Next Day</span>
          </Button>
        </div>
      </div>
      
      <div className="text-center my-4">
        <h2 className="text-2xl font-headline">{format(currentDate, 'MMMM do, yyyy')}</h2>
      </div>

      {filteredAnswers.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredAnswers.map((answer, index) => (
            <AnswerCard key={answer.id} answer={answer} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 border-2 border-dashed rounded-lg bg-card">
          <h3 className="text-xl font-semibold font-headline">No Answers Found</h3>
          <p className="text-muted-foreground mt-2">Try selecting another category or date.</p>
        </div>
      )}
    </div>
  );
}
