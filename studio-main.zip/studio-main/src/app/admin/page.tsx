'use client';

import { useState } from 'react';
import { mockData } from '@/lib/data';
import type { DailyAnswer } from '@/lib/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Download, MoreHorizontal, CheckCircle, XCircle, Trash2, Edit } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';


export default function AdminPage() {
  const [answers, setAnswers] = useState<DailyAnswer[]>(mockData);
  const { toast } = useToast();

  const handleDelete = (id: string) => {
    setAnswers(currentAnswers => currentAnswers.filter((a) => a.id !== id));
    toast({
      title: "Answer Deleted",
      description: "The answer has been successfully deleted.",
    });
  };
  
  const handleStatusChange = (id: string, status: DailyAnswer['status']) => {
    setAnswers(currentAnswers => currentAnswers.map(a => a.id === id ? {...a, status} : a));
    toast({
        title: "Status Updated",
        description: `Answer has been ${status}.`,
    });
  };

  const handleRefresh = () => {
    toast({
        title: "Refreshing Content...",
        description: "Simulating manual content refresh.",
    });
    // In a real app, this would trigger a server action or API call.
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold font-headline">Content Management</h1>
        <Button onClick={handleRefresh}>
          <Download className="mr-2 h-4 w-4" />
          Manually Refresh Content
        </Button>
      </div>

      <div className="border rounded-lg bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[40%]">Title</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {answers.map((answer) => (
              <TableRow key={answer.id}>
                <TableCell className="font-medium max-w-sm truncate">{answer.title}</TableCell>
                <TableCell>{answer.source}</TableCell>
                <TableCell><Badge variant="outline">{answer.category}</Badge></TableCell>
                <TableCell>{answer.date}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      answer.status === 'approved'
                        ? 'default'
                        : answer.status === 'pending'
                        ? 'secondary'
                        : 'destructive'
                    }
                  >
                    {answer.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => alert('Editing is not implemented in this demo.')}>
                        <Edit className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => handleStatusChange(answer.id, 'approved')}>
                        <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Approve
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleStatusChange(answer.id, 'rejected')}>
                        <XCircle className="mr-2 h-4 w-4 text-orange-500" /> Reject
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" className="w-full justify-start text-sm p-2 text-red-600 hover:text-red-600 font-normal relative">
                                <Trash2 className="mr-2 h-4 w-4" /> Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the answer.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(answer.id)}>Continue</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
