'use server';

/**
 * @fileOverview A flow that summarizes long answers using GenAI.
 *
 * - summarizeAnswer - A function that summarizes a long answer.
 * - SummarizeAnswerInput - The input type for the summarizeAnswer function.
 * - SummarizeAnswerOutput - The return type for the summarizeAnswer function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeAnswerInputSchema = z.object({
  answer: z.string().describe('The long answer to be summarized.'),
});
export type SummarizeAnswerInput = z.infer<typeof SummarizeAnswerInputSchema>;

const SummarizeAnswerOutputSchema = z.object({
  summary: z.string().describe('The summarized answer.'),
});
export type SummarizeAnswerOutput = z.infer<typeof SummarizeAnswerOutputSchema>;

export async function summarizeAnswer(input: SummarizeAnswerInput): Promise<SummarizeAnswerOutput> {
  return summarizeAnswerFlow(input);
}

const summarizeAnswerPrompt = ai.definePrompt({
  name: 'summarizeAnswerPrompt',
  input: {schema: SummarizeAnswerInputSchema},
  output: {schema: SummarizeAnswerOutputSchema},
  prompt: `Summarize the following answer in 2-3 sentences:\n\n{{{answer}}}`,
});

const summarizeAnswerFlow = ai.defineFlow(
  {
    name: 'summarizeAnswerFlow',
    inputSchema: SummarizeAnswerInputSchema,
    outputSchema: SummarizeAnswerOutputSchema,
  },
  async input => {
    const {output} = await summarizeAnswerPrompt(input);
    return output!;
  }
);
