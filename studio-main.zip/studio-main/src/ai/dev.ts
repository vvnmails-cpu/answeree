import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-long-answers.ts';